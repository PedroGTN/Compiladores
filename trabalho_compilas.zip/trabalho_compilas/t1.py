import sys
from antlr4 import *
from ExprLexer import ExprLexer
from ExprParser import ExprParser

archive_input, archive_out = sys.argv[1:]

input_string = FileStream(archive_input)
lexer = ExprLexer(input_string)
stream = CommonTokenStream(lexer)
parser = ExprParser(stream)
tree = parser.start_()
print(tree)


print(archive_input)
print(archive_out)