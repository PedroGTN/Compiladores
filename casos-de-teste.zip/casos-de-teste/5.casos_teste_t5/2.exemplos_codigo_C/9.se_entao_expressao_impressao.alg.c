/*
  Comando 'se-entao-senao' com impressao
  Helena Caseli
  2010
*/

#include <stdio.h>
#include <stdlib.h>

int main() {
	if (4 > 3 && 4 < 5) {
		printf("4 eh maior do que 3 e menor do que 5");
	}
	return 0;
}
